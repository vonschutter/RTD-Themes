## Vimix Icon Theme
    A Material Design icon theme

Vimix icon theme is based on Paper-Icon-Theme: https://github.com/snwh/paper-icon-theme

## Install Or Uninstall
Run

    ./install.sh
## Install with all color variants
    ./install.sh -a

Or double-click to open that script files and select "run at the terminal" at nautilus.

## Preview
![1](../master/Preview.png)
![2](../master/Preview01.png)
