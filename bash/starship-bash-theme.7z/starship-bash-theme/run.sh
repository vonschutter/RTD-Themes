#!/bin/bash
# PUBLICATION="RTD Simple Global Theme Install"
# VERSION="1.00"
#
#::             Linux bash Theme Installer Script
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter adapted from Chris Titus "Mybash"
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install bash Theme globally
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


home_directory=/home/${SUDO_USER:-tangarora}
home_template_directory=/etc/skel
base_target_directory=/usr/bin
base_config_directory=/etc/rtd
DEPENDENCIES='autojump bash-completion tar curl trash-cli'



installDepend() {
	echo -e "🚧 Installing dependencies..."
	for _pkgmgr in zypper dnf apt ; do
		if hash ${_pkgmgr} &>/dev/null ; then
			for i in ${DEPENDENCIES} ; do
				hash $i || sudo ${_pkgmgr} install -y $i
			done
		fi
	done
}


install_starship ()
{
	if [[ -e ./$(basename $0 )  ]]; then
		echo "✅ OK I see the payload!"
	else
		echo "🐞 Problem: I am not in the right place: $(pwd) $(ls -l)"
		exit
	fi

	mkdir -p ${base_target_directory}
	mkdir -p ${base_config_directory}

	if command_exists starship; then
		echo "✅ Starship already installed"
		return
	fi

	if curl -s --max-time 2 https://httpbin.org/ip > /dev/null; then
		# Try to get starship from the official source...
		echo "🌎 Online Accessible..."
		if ! curl -sS https://starship.rs/install.sh | sh -s -- --force ;then
			echo -e "👿 Something went wrong during starship install! \n This is non critical, please investigate. Using local copy... "
			cp -v starship ${base_target_directory}/
			chmod 755 ${base_target_directory}/starship
		fi
	else
		echo "🚧 Internet is inaccessible: installing local copy of starship"
		cp -v starship ${base_target_directory}/
		chmod 755 ${base_target_directory}/starship
	fi
}

install_oem_starship_config ()
{
	if cp -v starship.toml bashrc ${base_config_directory}/ ; then

		chmod 755 ${base_config_directory}/bashrc
		chmod 755 ${base_config_directory}/starship.toml

		if mv "${home_directory}/.bashrc" "${home_directory}/.config/bashrc-$(date '+%Y/%m/%d %H:%M').bak" ; then
			cp -v "${base_config_directory}/bashrc" "${home_directory}/.bashrc"
		fi

		if mv -f "${home_template_directory}/.bashrc" "${home_template_directory}/.bashrc-$(date '+%Y/%m/%d %H:%M').bak" ; then
			cp -v ${base_config_directory}/bashrc ${home_template_directory}/.bashrc
		fi

		ln -svf ${base_config_directory}/starship.toml "${home_directory}/.config/starship.toml"
		ln -svf ${base_config_directory}/starship.toml "${home_template_directory}/.config/starship.toml"
	else
		echo "🐞 Error installing bashrc and toml files"
	fi
}




if installDepend ; then
	echo "✅ Dependency install appear to have been successful..."
else
	echo "🐞 installDepend reported an error while trying to satisfy dependencies..."
fi


if install_starship ; then
	echo -e "✅ Starship bash enhancement installed..."
else
	echo "🐞 there was a problem installing the starship for bash..."
fi


if install_oem_starship_config ; then
	echo -e "✅ Configuration successful: Make sure to use one of the NERD fonts in the included font themes..."
else
	echo "🐞 there was a problem installing the payload..."
fi



