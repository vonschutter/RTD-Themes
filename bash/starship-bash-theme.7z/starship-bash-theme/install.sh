#!/bin/bash
PUBLICATION="RTD Simple Global Theme Install"
VERSION="1.00"
#
#::             Linux bash Theme Installer Script
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter adapted from Chris Titus "Mybash"
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install bash Theme globally
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


home_directory=/home/${SUDO_USER:-tangarora}
home_template_directory=/etc/skel
base_target_directory=/usr/bin
base_config_directory=/etc/rtd
DEPENDENCIES='autojump bash bash-completion tar curl trash-cli'


RC='\e[0m'
RED='\e[31m'
YELLOW='\e[33m'
GREEN='\e[32m'



installDepend() {
	echo -e "${YELLOW}Installing dependencies...${RC}"
	for _pkgmgr in zypper dnf apt aur ; do
		if hash ${_pkgmgr} &>/dev/null ; then
			for i in ${DEPENDENCIES} ; do
				hash $i || sudo ${_pkgmgr} install -y $i
			done
		fi
	done
}


install_payload ()
{
	if [[ -e ./$(basename $0 )  ]]; then
		echo "OK I see the payload!"
	else
		echo "Problem: I am not in the right place: $(pwd) $(ls -l)"
		exit
	fi

	mkdir -p ${base_target_directory}
	mkdir -p ${base_config_directory}

	mv -f starship ${base_target_directory}/
	chmod 755 ${base_target_directory}/starship

	if mv -f starship.toml bashrc ${base_config_directory}/ ; then
		if mv ${home_directory}/.bashrc ${home_directory}/.config/.bashrc.bak ; then
			ln -svf ${base_config_directory}/bashrc ${home_directory}/.bashrc
		fi

		if rm ${home_template_directory}/.bashrc ; then
			ln -svf ${base_config_directory}/bashrc ${home_template_directory}/.bashrc
		fi
		chmod 755 ${base_config_directory}/bashrc
		chmod 755 ${base_config_directory}/starship.toml
		ln -svf ${base_config_directory}/starship.toml ${home_directory}/.config/starship.toml
		ln -svf ${base_config_directory}/starship.toml ${home_template_directory}/.config/starship.toml
	else
		echo "Error installing bashrc and toml files"
	fi
}




installDepend
install_payload && echo -e "${YELLOW} Make sure to use one of the NERD fonts in the included font themes...${RC}"



