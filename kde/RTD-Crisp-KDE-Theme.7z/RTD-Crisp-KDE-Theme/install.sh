#!/bin/bash
PUBLICATION="RTD Simple User Theme Install"
VERSION="1.00"
#
#::             Linux Theme Installer Script for KDE
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install a KDE global theme
#::              and optonially enable it.
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Script Settings                 ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

: ${_theme_dir:="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"}

function check_install_target ()
{
    if [[ ${UID} -eq 0 ]] ; then
        : ${_look_and_feel="/usr/share/plasma/look-and-feel"}
        : ${_icon_dir="/usr/share/icons"}
        : ${_desktoptheme="/usr/share/plasma/desktoptheme"}
        : ${_wallpapers="/usr/share/plasma/wallpapers"}
        : ${_window_decorations="/usr/share/aurorae/themes"}
    else
        : ${_look_and_feel="$HOME/.local/share/plasma/look-and-feel"}
        : ${_icon_dir="$HOME/.local/share/icons"}
        : ${_desktoptheme="$HOME/.local/share/plasma/desktoptheme"}
        : ${_wallpapers="/.local/share/plasma/wallpapers"}
        : ${_window_decorations="$HOME/.local/share/aurorae/themes"}
    fi
}


#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Script functions                ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


function deploy::theme ()
{
    check_install_target
    
    mkdir -p  ${_look_and_feel}
    cp -r -f -u -v ${_theme_dir}/look-and-feel/* ${_look_and_feel}/
    chmod 755 -R ${_look_and_feel}

    mkdir -p ${_icon_dir}
    cp -r -f -u -v ${_theme_dir}/icons/* ${_icon_dir}/
    chmod 755 -R ${_icon_dir}

    mkdir -p ${_desktoptheme}
    cp -r -f -u -v ${_theme_dir}/desktoptheme/*  ${_desktoptheme}/
    chmod 755 -R ${_desktoptheme}

    mkdir -p ${_window_decorations}
    cp -r -f -u -v ${_theme_dir}/window-decorations/*  ${_window_decorations}/
    chmod 755 -R ${_window_decorations}

    mkdir -p ${_wallpapers}
    cp -r -f -u -v ${_theme_dir}/wallpapers/*  ${_wallpapers}/
    chmod 755 -R ${_wallpapers}
    
}


function apply::theme ()
{
    if [ ! "$UID" -eq 0 ]; then
        lookandfeeltool -a 'RTD-Win11-Light' --resetLayout
    else
        sudo -H -u $SUDO_USER XDG_RUNTIME_DIR="/run/user/${SUDO_UID}" bash -c '/usr/bin/lookandfeeltool -a RTD-Win11-Light --resetLayout'
    fi
}

function usage() 
{ 
    echo "To force options USAGE: $0 [--install-theme global/local] [--apply-theme true/false]
    alternatively allow the script to detect the best options by passing no arguments at all.
    If you pass nonsense arguments to the script they will be ignored." 1>&2; exit 1; 

}


function get::options ()
{
    options=$(getopt -n theme-installer --options i:,a:,h --longoptions install-theme:,apply-theme:,help -- "$@" )
    eval set -- ${options}

    while :
    do
        case "${1}" in
            --install-theme)
                export install_theme="${2}"
                shift 2
                ;;
            --apply-theme)
                export apply_theme="${2}"
                shift 2
                ;;
            --help)
                usage
                ;;
            --)
                shift;
                break
                ;;
            *)
                : ${install_theme=auto}
                : ${apply_theme=auto}
                ;;
        esac
    done
}

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Sript Flow Control              ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


get::options $@

case "$install_theme" in
    global ) sudo -E  bash -c "$( declare -f deploy::theme; declare -f check_install_target ) ; check_install_target ; deploy::theme" ;;
    local ) deploy::theme ;;
    *) deploy::theme ;;
esac


case "${apply_theme}" in
    true) apply::theme ;;
    false) echo "application of theme requested not to" ;;
        *) echo "application of theme not requested" ;;
esac
