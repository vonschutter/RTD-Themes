## Avengers Gtk Theme

Avengers gtk theme is special version of Qogir gtk theme, I designed this theme just for my favorite Marvel heros.
This theme is just for personal use only, wish you have fun!

## Info

### GTK+ 3.20 or later
- Set windows button on gnome for a better experience.

Gnome ≥ 3.22:

    gsettings set org.gnome.desktop.wm.preferences button-layout appmenu:minimize,maximize,close


### GTK2 engines requirment
- GTK2 engine Murrine 0.98.1.1 or later.
- GTK2 pixbuf engine or the gtk(2)-engines package.

Fedora/RedHat distros:

    yum install gtk-murrine-engine gtk2-engines

Ubuntu/Mint/Debian distros:

    sudo apt-get install gtk2-engines-murrine gtk2-engines-pixbuf

ArchLinux:

    pacman -S gtk-engine-murrine gtk-engines

Other:
Search for the engines in your distributions repository or install the engines from source.

## Install

  ./installer.sh

## Screenshots
![1](https://github.com/vinceliuice/Avengers-gtk-theme/blob/master/screenshot.jpeg?raw=true)
